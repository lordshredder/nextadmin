const Bosses = () => {
    return (
      <div>Bosses</div>
    )
  }
  
  export default Bosses